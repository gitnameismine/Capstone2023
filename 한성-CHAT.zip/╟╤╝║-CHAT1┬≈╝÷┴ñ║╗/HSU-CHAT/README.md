# 한성-CHAT

과목 별 대화방에서의 실시간 채팅 웹 어플리케이션

### Server 실행

<b>npm start</b>
<br>
port:3000

### 설치 라이브러리

    "ejs": "^3.1.6",
    "express": "^4.17.1",
    "moment": "^2.29.1",
    "mysql": "^2.18.1",
    "socket.io": "^4.4.0"

![Untitled](https://user-images.githubusercontent.com/84308554/152974072-3e5480e7-f519-42a9-864f-9a4750256d51.png)
